/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question02;

/**
 *
 * @author S542312
 */
public interface Colorable {
	/** Describe how to color */
	String howToColor();
}
