/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question10;

/**
 *
 * @author S542312
 */
public class Recursion {

     static int arr[] = {2, 34, 44, 7, 66};
      
     /* Recursive Method to search x in arr[l..r] */
     static int recSearch(int arr[], int p, int q, int x)
     {
          if (q < p)
             return -1;
          if (arr[p] == x)
             return p;
          if (arr[q] == x)
             return q;
          return recSearch(arr, p+1, q-1, x);
     }
      
    public static void main(String[] args) {
        // TODO code application logic here
        int z = 44;
         
        //Method call to find x
        int index = recSearch(arr, 0, arr.length-1, z);
        if (index != -1)
           System.out.println("Element " + z + " is present at index " +
                                                    index);
        else
            System.out.println("Element " + z + " is not present");
        }
}
    

