/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question10;

/**
 *
 * @author S542312
 */
public class Recursion02 {

    /**
     * @param args the command line arguments
     */
    static int factorial( int f ) {
        if (f != 0)  // termination condition
            return f * factorial(f-1); // recursive call
        else
            return 1;
    }
    public static void main(String[] args) {
        // TODO code application logic here
        int number = 12, result;
        result = factorial(number);
        System.out.println(number + " factorial = " + result);
    }

}
    

