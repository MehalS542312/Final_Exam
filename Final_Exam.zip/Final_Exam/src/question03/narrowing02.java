/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question03;
/**
 *
 * @author S542312
 */
public class narrowing02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double x = 166.66;  
//converting double data type into long data type  
long y = (long)x;  
//converting long data type into int data type  
int z = (int)y;  
System.out.println("Before conversion: "+x);  
//fractional part lost  
System.out.println("After conversion into long type: "+y);  
//fractional part lost  
System.out.println("After conversion into int type: "+z);  
    }
    
}
