/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question03;
/**
 *
 * @author S542312
 */
public class narrowing01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // create double type variable
    double number = 10.99;
    System.out.println("The double value: " + number);

    // convert into int type
    int data = (int)number;
    System.out.println("The integer value: " + data);
    }
    
}
