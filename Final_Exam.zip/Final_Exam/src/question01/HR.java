/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question01;

/**
 *
 * @author S542312
 */
public class HR extends EmployeeDetails {
private int salary;
private String performance;
 
@Override
public void confidentialDetails(int s,String p) {
this.salary=s;
this.performance=p;
System.out.println("Salary = "+salary);
System.out.println("Performance = "+performance);
}

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        HR hr =new HR();
        hr.confidentialDetails(50000,"Excellent");
}
}
    
    
