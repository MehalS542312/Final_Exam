/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question01;
/**
 *
 * @author S542312
 */
public class Interface01 implements Engine {
int speed;
int gear;

public void speedUp(int a) {
this.speed=a;
System.out.println("speed"+speed);
}
 
public void changeGear(int a) {
this.gear=a;
System.out.println("gear"+gear);
}
/**
 * @param args the command line arguments
 */
public static void main(String[] args) {
   // TODO code application logic here
     Interface01 obj=new Interface01();
       obj.changeGear(5);
       obj.speedUp(120);
    }
}
