/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question01;

/**
 *
 * @author S542312
 */
public abstract class EmployeeDetails {
private String name;
private int emp_ID;
 
public void commonEmpDetaills()
{
System.out.println("Name"+name);
System.out.println("emp_ID"+emp_ID);
}
public abstract void confidentialDetails(int m,String r);
 
}
