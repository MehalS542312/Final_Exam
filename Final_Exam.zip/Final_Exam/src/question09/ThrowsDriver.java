/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question09;

/**
 *
 * @author S542312
 */
public class ThrowsDriver {

int division(int x, int y) throws ArithmeticException{ 

      int m = x/y;

      return m;

}

    /**

     * @param args the command line arguments

     */

    public static void main(String[] args) {

        // TODO code application logic here

        ThrowsDriver thr = new ThrowsDriver();

      try{

         System.out.println(thr.division(14, 0)); 

      }

      catch(ArithmeticException e){

         System.out.println("You cannot divide number by zero");

      }

    }

   

}


    
    

