/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question09;

/**
 *
 * @author S542312
 */

public class Throws {

    double division(double x, double y) throws ArithmeticException{ 

      double m = x/y;

      return m;

    }

}

 


    

