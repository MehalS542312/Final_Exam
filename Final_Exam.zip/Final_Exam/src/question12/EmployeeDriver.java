/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question12;

import java.util.ArrayList;
import java.util.Collections;
/**
 *
 * @author S542312
 */
public class EmployeeDriver {

   public static void main(String[] args) {

       ArrayList<Employee> emp = new ArrayList<Employee>();
       emp.add(new Employee(12345, "Mehal", 96000));
       emp.add(new Employee(12346, "Roopin", 34000));
       emp.add(new Employee(12347, "Naveen", 60000));
       emp.add(new Employee(12348, "Yaswant", 56000));
       emp.add(new Employee(12349, "Vinod", 78000));

       System.out.println("Displaying the employees List :");
       display(emp);
      

       Collections.sort(emp);
       System.out.println("\n\nAfter Sorting displaying the employees List :");
       display(emp);
      

Collections.sort(emp, new SortBySalary());
       System.out.println("\n\nAfter Sorting by salary displaying the employees List :");
display(emp);
  
      
Collections.sort(emp, new SortByName());
System.out.println("\n\nAfter Sorting by employee name displaying the employees List :");
display(emp);
   }

   private static void display(ArrayList<Employee> emps) {
       for (Employee emp : emps) {
           System.out.println(emp);
       }
      
   }

}