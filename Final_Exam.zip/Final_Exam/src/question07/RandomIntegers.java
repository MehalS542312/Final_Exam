/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question07;

import java.util.Random;
import java.util.Scanner;
/**
 *
 * @author S542312
 */
public class RandomIntegers {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Random r = new Random();

        int[] arrays = new int[100];

        for (int i = 0; i < arrays.length; i++) {

            arrays[i] = r.nextInt(100);

        }

        System.out.print("Enter index value 0 - " + (arrays.length - 1) + " : ");

        int index = sc.nextInt();

        if (index < 0 || index > arrays.length - 1) {

            System.out.println("Out of Bounds");

        } else {

            System.out.println("The value in the index is : " + arrays[index]);

        }

    }

}
