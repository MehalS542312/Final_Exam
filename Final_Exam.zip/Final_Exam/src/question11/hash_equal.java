/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question11;

/**
 *
 * @author S542312
 */
public class hash_equal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String x = "University";  
        String y = "University";  
  
        if(x.equals(y)){   //checking the equality of objects using equals() methods  
            System.out.println("x & y are equal variables, and their respective hashvalues are:" + " "+ x.hashCode() + " & " + y.hashCode());  
          
        }  
  
        String p = "Mehal";  
        String q= "Reddy";  
  
        if(!p.equals(q)){    //checking  the equality of objects using equals() method  
            System.out.println("\np & q are Un-equal variables, and their respective hashvalues are:" + " "+ p.hashCode() + " & " + q.hashCode());  
              
        }  
    }  
}  
    
    

